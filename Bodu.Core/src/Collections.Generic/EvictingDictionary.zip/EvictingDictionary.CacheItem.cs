﻿// ---------------------------------------------------------------------------------------------------------------
// <copyright file="EvictingDictionary.CacheItem.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>
// ---------------------------------------------------------------------------------------------------------------

namespace Bodu.Collections.Generic
{
	public partial class EvictingDictionary<TKey, TValue>
	{
		private record class CacheItem
		{
			public TValue Value { get; }
			public LinkedListNode<TKey> Node { get; set; }
			public int Frequency { get; set; }

			public CacheItem(TValue value, LinkedListNode<TKey> node)
			{
				Value = value;
				Node = node;
				Frequency = 0;
			}
		}
		}
}
