﻿// ---------------------------------------------------------------------------------------------------------------
// <copyright file="EvictingDictionary.CacheItem.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>
// ---------------------------------------------------------------------------------------------------------------

using System.Collections;

namespace Bodu.Collections.Generic
{
	public partial class EvictingDictionary<TKey, TValue>
	{
		/// <summary>
		/// Enumerates the elements of a <see cref="EvictingDictionary{TKey, TValue}"/>.
		/// </summary>
		/// <remarks>
		/// <para>Use the <see langword="foreach"/> statement to simplify the enumeration process instead of directly using this enumerator.</para>
		/// <para>The enumerator provides read-only access to the dictionary's elements. Modifying the underlying dictionary while enumerating invalidates the enumerator.</para>
		/// </remarks>
		public struct DictionaryEnumerator
			: System.Collections.IDictionaryEnumerator
		{
			/// <inheritdoc />
			private readonly IEnumerator<KeyValuePair<TKey, TValue>> inner;

			/// <inheritdoc />
			public DictionaryEnumerator(IEnumerator<KeyValuePair<TKey, TValue>> inner)
			{
				this.inner = inner;
			}

			/// <inheritdoc />
			public DictionaryEntry Entry => new(inner.Current.Key!, inner.Current.Value);

			/// <inheritdoc />
			public object Key => inner.Current.Key!;

			/// <inheritdoc />
			public object? Value => inner.Current.Value;

			/// <inheritdoc />
			public object Current => Entry;

			/// <inheritdoc />
			public bool MoveNext() => inner.MoveNext();

			/// <inheritdoc />
			public void Reset() => inner.Reset();
		}
	}
}