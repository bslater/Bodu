﻿// ---------------------------------------------------------------------------------------------------------------
// <copyright file="EvictingDictionary.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>
// ---------------------------------------------------------------------------------------------------------------

using System.Diagnostics;

namespace Bodu.Collections.Generic
{
	/// <summary>
	/// Represents a fixed-capacity dictionary that automatically removes entries based on a chosen eviction policy,
	/// such as First-In-First-Out (FIFO), Least Recently Used (LRU), or Least Frequently Used (LFU).
	/// </summary>
	/// <typeparam name="TKey">Specifies the type of keys in the dictionary.</typeparam>
	/// <typeparam name="TValue">Specifies the type of values in the dictionary.</typeparam>
	/// <remarks>
	/// <para>
	/// <see cref="EvictingDictionary{TKey, TValue}"/> maintains a maximum number of key-value pairs and automatically evicts items when capacity is exceeded.
	/// Eviction is determined by a specified <see cref="EvictionPolicy"/>, allowing this dictionary to behave like a queue, an access-order cache, or a frequency-based cache.
	/// </para>
	/// <para>
	/// The supported <see cref="EvictionPolicy"/> values are:
	/// </para>
	/// <list type="bullet">
	/// <item><description><see cref="EvictionPolicy.FIFO"/> evicts the item that was added first, in first-in, first-out order.</description></item>
	/// <item><description><see cref="EvictionPolicy.LRU"/> evicts the least recently accessed item, updating the usage order on every read and write.</description></item>
	/// <item><description><see cref="EvictionPolicy.LFU"/> evicts the least frequently accessed item, promoting items as their usage count increases.</description></item>
	/// </list>
	/// <para>
	/// Common operations supported by <see cref="EvictingDictionary{TKey, TValue}"/> include:
	/// </para>
	/// <list type="bullet">
	/// <item><description><see cref="EvictingDictionary{TKey, TValue}.Add(TKey, TValue)"/> adds a key-value pair and may evict an existing entry if the dictionary is at capacity.</description></item>
	/// <item><description><see cref="EvictingDictionary{TKey, TValue}.TryGetValue(TKey, out TValue)"/> retrieves a value by key and updates its usage metadata if the policy is LRU or LFU.</description></item>
	/// <item><description><see cref="EvictingDictionary{TKey, TValue}.Remove(TKey)"/> removes the entry for a specified key.</description></item>
	/// <item><description><see cref="EvictingDictionary{TKey, TValue}.Clear()"/> removes all entries from the dictionary.</description></item>
	/// </list>
	/// <para>
	/// Unlike <see cref="System.Collections.Generic.Dictionary{TKey, TValue}"/>, this type ensures the total number of entries never exceeds the configured <see cref="EvictingDictionary{TKey, TValue}.Capacity"/>.
	/// The eviction behavior makes it useful for caching scenarios, memory-bound lookup tables, or history-aware key-value stores.
	/// </para>
	/// <para>
	/// <see cref="EvictingDictionary{TKey, TValue}"/> allows <see langword="null"/> keys and values (for reference types) and supports custom key equality via <see cref="System.Collections.Generic.IEqualityComparer{T}"/>.
	/// </para>
	/// <para>
	/// The following examples demonstrate typical usage scenarios for <see cref="EvictingDictionary{TKey, TValue}"/>.
	/// </para>
	///
	/// <example>
	/// <code language="csharp">
	/// using System;
	/// using Bodu.CoreLib.Collections.Generic;
	///
	/// // Example 1: Basic FIFO cache
	/// var cache = new EvictingDictionary&lt;string, int&gt;(capacity: 3, policy: EvictionPolicy.FIFO);
	/// cache.Add("one", 1);
	/// cache.Add("two", 2);
	/// cache.Add("three", 3);
	/// cache.Add("four", 4); // "one" is evicted (FIFO)
	///
	/// Console.WriteLine(cache.ContainsKey("one"));   // False
	/// Console.WriteLine(cache.ContainsKey("four"));  // True
	/// </code>
	/// </example>
	///
	/// <example>
	/// <code language="csharp">
	/// // Example 2: Least Recently Used (LRU) behavior
	/// var lruCache = new EvictingDictionary&lt;string, string&gt;(3, EvictionPolicy.LRU);
	/// lruCache.Add("A", "Apple");
	/// lruCache.Add("B", "Banana");
	/// lruCache.Add("C", "Carrot");
	///
	/// var _ = lruCache["A"]; // Access "A" to make it most recently used
	/// lruCache.Add("D", "Date"); // Evicts "B" (least recently used)
	///
	/// Console.WriteLine(lruCache.ContainsKey("B")); // False
	/// Console.WriteLine(lruCache.ContainsKey("A")); // True
	/// </code>
	/// </example>
	///
	/// <example>
	/// <code language="csharp">
	/// // Example 3: Least Frequently Used (LFU) behavior
	/// var lfuCache = new EvictingDictionary&lt;int, string&gt;(2, EvictionPolicy.LFU);
	/// lfuCache.Add(1, "one");
	/// lfuCache.Add(2, "two");
	///
	/// // Access 1 multiple times
	/// var temp = lfuCache[1];
	/// temp = lfuCache[1];
	///
	/// // Add a third item, triggering LFU eviction
	/// lfuCache.Add(3, "three"); // Evicts 2 (less frequently accessed than 1)
	///
	/// Console.WriteLine(lfuCache.ContainsKey(2)); // False
	/// Console.WriteLine(lfuCache.ContainsKey(1)); // True
	/// </code>
	/// </example>
	///
	/// <example>
	/// <code language="csharp">
	/// // Example 4: Using custom equality comparer
	/// var ignoreCaseDict = new EvictingDictionary&lt;string, string&gt;(
	///     capacity: 2,
	///     policy: EvictionPolicy.LRU,
	///     comparer: StringComparer.OrdinalIgnoreCase
	/// );
	///
	/// ignoreCaseDict["Key"] = "Value";
	/// Console.WriteLine(ignoreCaseDict.ContainsKey("key")); // True
	/// </code>
	/// </example>
	/// </remarks>
	[DebuggerDisplay("Count = {Count}, Capacity = {_capacity}, Policy = {_policy}")]
	[DebuggerTypeProxy(typeof(EvictingDictionaryDebugView<,>))]
	[Serializable]
	public partial class EvictingDictionary<TKey, TValue>
		where TKey : notnull
	{
		private const int DefaultCapacity = 16;
		private const EvictionPolicy DefaultPolicy = EvictionPolicy.LRU;

		private readonly int capacity;
		private readonly EvictionPolicy policy;
		private long evictionCount;
		private long totalTouches;

		private readonly Dictionary<TKey, CacheItem> store;
		private LinkedList<TKey> order = null!; // FIFO/LRU
		private readonly SortedDictionary<int, LinkedList<TKey>> frequencyList=null!; // LFU}
		private readonly IEqualityComparer<TKey> comparer;

		/// <summary>
		/// Gets the maximum number of items that can be stored in the dictionary before eviction occurs.
		/// </summary>
		public int Capacity => capacity;

		/// <summary>
		/// Gets the eviction policy configured for this dictionary.
		/// </summary>
		public EvictionPolicy Policy => policy;

		/// <summary>
		/// Gets the total number of items evicted from the dictionary since creation.
		/// </summary>
		public long EvictionCount => evictionCount;

		/// <summary>
		/// Gets the total number of times any key has been accessed or touched.
		/// </summary>
		public long TotalTouches => totalTouches;

		/// <summary>
		/// Returns the keys in logical eviction order according to the current policy:
		/// FIFO and LRU are in insertion/access order; LFU is in increasing frequency order.
		/// </summary>
		public IEnumerable<TKey> OrderedKeys		=> 
			GetOrderedItems().Select(kvp => kvp.Key).ToList();

		/// <summary>
		/// Initializes a new empty <see cref="EvictingDictionary{TKey, TValue}"/> with the default capacity and eviction policy.
		/// </summary>
		/// <remarks>
		/// The default capacity is 16, and the default eviction policy is <see cref="EvictionPolicy.LRU"/>.
		/// </remarks>
		public EvictingDictionary()
			: this(DefaultCapacity, DefaultPolicy, null) { }

		/// <summary>
		/// Initializes a new empty <see cref="EvictingDictionary{TKey, TValue}"/> with the specified capacity and the default eviction policy.
		/// </summary>
		/// <param name="capacity">The maximum number of key-value pairs the dictionary can contain. Must be positive.</param>
		/// <exception cref="ArgumentOutOfRangeException">Thrown when <paramref name="capacity"/> is less than or equal to zero.</exception>
		/// <remarks>The default eviction policy is <see cref="EvictionPolicy.LRU"/>.</remarks>
		public EvictingDictionary(int capacity) 
			: this(capacity, DefaultPolicy, null) { }

		/// <summary>
		/// Initializes a new empty <see cref="EvictingDictionary{TKey, TValue}"/> with the specified capacity and eviction policy.
		/// </summary>
		/// <param name="capacity">The maximum number of key-value pairs the dictionary can contain. Must be positive.</param>
		/// <param name="policy">The eviction policy to use when the dictionary exceeds its capacity.</param>
		/// <exception cref="ArgumentOutOfRangeException">Thrown when <paramref name="capacity"/> is less than or equal to zero.</exception>

		public EvictingDictionary(int capacity, EvictionPolicy policy)
			: this(capacity, policy, null) { }

		/// <summary>
		/// Initializes a new empty <see cref="EvictingDictionary{TKey, TValue}"/> with the specified capacity and key comparer.
		/// </summary>
		/// <param name="capacity">The maximum number of key-value pairs the dictionary can contain. Must be positive.</param>
		/// <param name="comparer">An equality comparer to use for comparing keys, or <see langword="null"/> to use the default comparer.</param>
		/// <exception cref="ArgumentOutOfRangeException">Thrown when <paramref name="capacity"/> is less than or equal to zero.</exception>
		/// <remarks>The default eviction policy is <see cref="EvictionPolicy.LRU"/>.</remarks>
		public EvictingDictionary(int capacity, IEqualityComparer<TKey>? comparer) 
			: this(capacity, DefaultPolicy, comparer) { }

		/// <summary>
		/// Initializes a new empty <see cref="EvictingDictionary{TKey, TValue}"/> with the specified capacity, eviction policy, and key comparer.
		/// </summary>
		/// <param name="capacity">The maximum number of key-value pairs the dictionary can contain. Must be positive.</param>
		/// <param name="policy">The eviction policy to use when the dictionary exceeds its capacity.</param>
		/// <param name="comparer">An equality comparer to use for comparing keys, or <see langword="null"/> to use the default comparer.</param>
		/// <exception cref="ArgumentOutOfRangeException">Thrown when <paramref name="capacity"/> is less than or equal to zero. A non-zero capacity is required to allow storing items.</exception>
		public EvictingDictionary(int capacity, EvictionPolicy policy, IEqualityComparer<TKey>? comparer)
		{
			ThrowHelper.ThrowIfZeroOrNegative(capacity);

			this.capacity = capacity;
			this.policy = policy;
			this.comparer = comparer ?? EqualityComparer<TKey>.Default;

			store = new Dictionary<TKey, CacheItem>(this.comparer);

			if (this.policy == EvictionPolicy.FIFO || this.policy == EvictionPolicy.LRU)
				order = new LinkedList<TKey>();

			if (this.policy == EvictionPolicy.LFU)
				frequencyList = new SortedDictionary<int, LinkedList<TKey>>();
		}

		/// <summary>
		/// Initializes a new <see cref="EvictingDictionary{TKey, TValue}"/> by copying entries from the specified dictionary,
		/// using default capacity and eviction policy.
		/// </summary>
		/// <param name="source">The enumerable collection of key-value pairs to copy. Must not be null.</param>
		/// <exception cref="ArgumentNullException">Thrown when <paramref name="source"/> is <see langword="null"/>.</exception>
		/// <remarks>
		/// If the number of entries in <paramref name="source"/> exceeds the default capacity (16), only the most recent entries
		/// are retained according to the default eviction policy (<see cref="EvictionPolicy.LRU"/>).
		/// </remarks>
		public EvictingDictionary(IEnumerable<KeyValuePair<TKey, TValue>> source)
			: this(DefaultCapacity, source, DefaultPolicy, null) { }

		/// <summary>
		/// Initializes a new <see cref="EvictingDictionary{TKey, TValue}"/> by copying entries from the specified enumerable source,
		/// using the specified capacity and the default eviction policy (<see cref="EvictionPolicy.LRU"/>).
		/// </summary>
		/// <param name="capacity">The maximum number of key-value pairs the dictionary can contain. Must be a positive integer.</param>
		/// <param name="source">The enumerable collection of key-value pairs to copy into the dictionary. Must not be <see langword="null"/>.</param>
		/// <exception cref="ArgumentNullException">Thrown when <paramref name="source"/> is <see langword="null"/>. </exception>
		/// <exception cref="ArgumentOutOfRangeException">		/// Thrown when <paramref name="capacity"/> is less than or equal to zero. </exception>
		/// <remarks>
		/// If the number of elements in <paramref name="source"/> exceeds <paramref name="capacity"/>, only the most recently
		/// added entries will be retained based on the default eviction policy (<see cref="EvictionPolicy.LRU"/>).
		/// </remarks>
		public EvictingDictionary(int capacity, IEnumerable<KeyValuePair<TKey, TValue>> source)
			: this(capacity, source, DefaultPolicy, null) { }

		/// <summary>
		/// Initializes a new <see cref="EvictingDictionary{TKey, TValue}"/> by copying entries from the specified dictionary,
		/// using the specified eviction policy and default capacity.
		/// </summary>
		/// <param name="source">The enumerable collection of key-value pairs to copy. Must not be null.</param>
		/// <param name="policy">The eviction policy to use when the dictionary exceeds its capacity.</param>
		/// <exception cref="ArgumentNullException">Thrown when <paramref name="source"/> is <see langword="null"/>.</exception>
		public EvictingDictionary(IEnumerable<KeyValuePair<TKey, TValue>> source, EvictionPolicy policy)
			: this(DefaultCapacity, source, policy, null) { }

		/// <summary>
		/// Initializes a new <see cref="EvictingDictionary{TKey, TValue}"/> by copying entries from the specified dictionary,
		/// using the specified capacity and eviction policy.
		/// </summary>
		/// <param name="capacity">The maximum number of key-value pairs the dictionary can contain. Must be positive.</param>
		/// <param name="source">The enumerable collection of key-value pairs to copy. Must not be null.</param>
		/// <param name="policy">The eviction policy to use when the dictionary exceeds its capacity.</param>
		/// <exception cref="ArgumentNullException">Thrown when <paramref name="source"/> is <see langword="null"/>.</exception>
		/// <exception cref="ArgumentOutOfRangeException">Thrown when <paramref name="capacity"/> is less than or equal to zero.</exception>
		public EvictingDictionary(int capacity, IEnumerable<KeyValuePair<TKey, TValue>> source, EvictionPolicy policy)
			: this(capacity, source, policy, null) { }

		/// <summary>
		/// Initializes a new <see cref="EvictingDictionary{TKey, TValue}"/> by copying entries from the specified dictionary,
		/// using the specified capacity, eviction policy, and key comparer.
		/// </summary>
		/// <param name="capacity">The maximum number of key-value pairs the dictionary can contain. Must be positive.</param>
		/// <param name="source">The enumerable collection of key-value pairs to copy. Must not be null.</param>
		/// <param name="policy">The eviction policy to use when the dictionary exceeds its capacity.</param>
		/// <param name="comparer">An equality comparer to use for comparing keys, or <see langword="null"/> to use the default comparer.</param>
		/// <exception cref="ArgumentNullException">Thrown when <paramref name="source"/> is <see langword="null"/>.</exception>
		/// <exception cref="ArgumentOutOfRangeException">Thrown when <paramref name="capacity"/> is less than or equal to zero.</exception>
		public EvictingDictionary(int capacity, IEnumerable<KeyValuePair<TKey, TValue>> source, EvictionPolicy policy, IEqualityComparer<TKey>? comparer)
			: this(capacity, policy, comparer)
		{
			ThrowHelper.ThrowIfNull(source);

			foreach (var kvp in source)
				Add(kvp.Key, kvp.Value);
		}

		/// <summary>
		/// Marks the specified key as recently accessed without retrieving its value.
		/// If the eviction policy is <see cref="EvictionPolicy.LRU"/> or <see cref="EvictionPolicy.LFU"/>, this updates the internal usage metadata.
		/// </summary>
		/// <param name="key">The key to touch.</param>
		/// <returns>
		/// <see langword="true"/> if the key exists and was marked as accessed; otherwise, <see langword="false"/>.
		/// </returns>
		public bool Touch(TKey key)
		{
			if (store.TryGetValue(key, out var item))
			{
				if (policy == EvictionPolicy.LRU)
					TouchLRU(key, item);
				else if (policy == EvictionPolicy.LFU)
					TouchLFU(key, item);

				totalTouches++; 
				
				return true;
			}

			return false;
		}

		/// <summary>
		/// Marks the specified key as recently accessed without retrieving its value,
		/// and throws an exception if the key does not exist in the dictionary.
		/// </summary>
		/// <param name="key">The key to touch.</param>
		/// <exception cref="KeyNotFoundException">
		/// Thrown when the specified key does not exist in the dictionary.
		/// </exception>
		/// <remarks>
		/// If the eviction policy is <see cref="EvictionPolicy.LRU"/> or <see cref="EvictionPolicy.LFU"/>, this updates the internal usage metadata.
		/// </remarks>
		public void TouchOrThrow(TKey key)
		{
			if (!Touch(key))
				throw new KeyNotFoundException($"The key '{key}' was not found in the dictionary.");
		}

		/// <summary>
		/// Returns the key that would be evicted next based on the current eviction policy and internal state.
		/// </summary>
		/// <returns>
		/// The key that is next in line for eviction, or <see langword="default"/> if the dictionary is empty.
		/// </returns>
		public TKey? PeekEvictionCandidate()
		{
			if ((policy == EvictionPolicy.FIFO || policy == EvictionPolicy.LRU) &&
				order is not null && order.First is not null)
			{
				return order.First.Value;
			}
			else if (policy == EvictionPolicy.LFU && frequencyList.Count > 0)
			{
				var firstBucket = frequencyList.First().Value;
				if (firstBucket is not null && firstBucket.First is not null)
					return firstBucket.First.Value;
			}

			return default;
		}

		/// <summary>
		/// Occurs immediately <b>before</b> an item is evicted from the <see cref="EvictingDictionary{TKey, TValue}"/> due to capacity limits.
		/// </summary>
		/// <remarks>
		/// <para>This event is raised before the item is removed from the collection, allowing consumers to inspect the key and value before eviction occurs.</para>
		/// <para>Common use cases include diagnostics, logging, cache warm-up, or state mirroring. This event is informational and cannot cancel or delay eviction.</para>
		/// </remarks>
		/// <example>
		/// <code language="csharp">
		/// var cache = new EvictingDictionary&lt;string, int&gt;(capacity: 2, policy: EvictionPolicy.FIFO);
		/// cache.ItemEvicting += (key, value) =>
		/// {
		///     Console.WriteLine($""[BeforeEvict] {key} = {value}"");
		/// };
		///
		/// cache.Add(""A"", 1);
		/// cache.Add(""B"", 2);
		/// cache.Add(""C"", 3); // Triggers ItemEvicting for ""A""
		/// </code>
		/// </example>
		public event Action<TKey, TValue>? ItemEvicting;

		/// <summary>
		/// Occurs immediately <b>after</b> an item is evicted from the <see cref="EvictingDictionary{TKey, TValue}"/> due to capacity limits.
		/// </summary>
		/// <remarks>
		/// <para>This event is raised after the item has been removed from the collection, based on the configured <see cref="EvictionPolicy"/> (e.g., FIFO, LRU, or LFU).</para>
		/// <para>Consumers can use this event to record historical data, notify observers, or synchronize external caches. The key and value provided are no longer present in the dictionary.</para>
		/// </remarks>
		/// <example>
		/// <code language="csharp">
		/// var cache = new EvictingDictionary&lt;string, int&gt;(capacity: 2, policy: EvictionPolicy.FIFO);
		/// cache.ItemEvicted += (key, value) =>
		/// {
		///     Console.WriteLine($""[AfterEvict] {key} = {value}"");
		/// };
		///
		/// cache.Add(""A"", 1);
		/// cache.Add(""B"", 2);
		/// cache.Add(""C"", 3); // Triggers ItemEvicted for ""A""
		/// </code>
		/// </example>
		public event Action<TKey, TValue>? ItemEvicted;

		/// <summary>
		/// Removes the next item to be evicted based on the current eviction policy.
		/// Raises the <see cref="ItemEvicted"/> event and updates eviction metrics.
		/// </summary>
		private void EvictOne()
		{
			TKey? keyToRemove = default;

			if ((policy == EvictionPolicy.FIFO || policy == EvictionPolicy.LRU)
				&& order?.First is not null)
			{
				keyToRemove = order.First.Value;
			}
			else if (policy == EvictionPolicy.LFU &&
					 frequencyList?.Count > 0 &&
					 frequencyList.First().Value?.First is LinkedListNode<TKey> node)
			{
				keyToRemove = node.Value;
			}

			// If key was selected and exists in the store
			if (keyToRemove is not null && store.TryGetValue(keyToRemove, out var item))
			{
				ItemEvicting?.Invoke(keyToRemove, item.Value);
				evictionCount++;
				Remove(keyToRemove); // handles cleanup
				ItemEvicted?.Invoke(keyToRemove, item.Value);
			}
		}

		/// <summary>
		/// Updates the access order of the specified key in the LRU eviction list,
		/// moving it to the most recently used position.
		/// </summary>
		/// <param name="key">The key being accessed.</param>
		/// <param name="item">The associated cache item for the key.</param>
		private void TouchLRU(TKey key, CacheItem item)
		{
			order.Remove(item.Node);
			item.Node = order.AddLast(key);
		}

		/// <summary>
		/// Increments the access frequency of the specified key in the LFU frequency map.
		/// Moves it to the appropriate frequency bucket.
		/// </summary>
		/// <param name="key">The key being accessed.</param>
		/// <param name="item">The associated cache item for the key.</param>
		private void TouchLFU(TKey key, CacheItem item)
		{
			RemoveFromFrequencyList(item.Frequency, key);
			item.Frequency++;
			AddToFrequencyList(item.Frequency, key);
		}

		/// <summary>
		/// Adds the specified key to the LFU frequency bucket for the given frequency.
		/// </summary>
		/// <param name="frequency">The new frequency count.</param>
		/// <param name="key">The key to add.</param>
		private void AddToFrequencyList(int frequency, TKey key)
		{
			if (!frequencyList.TryGetValue(frequency, out var list))
			{
				list = new LinkedList<TKey>();
				frequencyList[frequency] = list;
			}
			list.AddLast(key);
		}

		/// <summary>
		/// Removes the specified key from the LFU frequency bucket for the given frequency.
		/// Cleans up the bucket if it becomes empty.
		/// </summary>
		/// <param name="frequency">The current frequency count of the key.</param>
		/// <param name="key">The key to remove.</param>
		private void RemoveFromFrequencyList(int frequency, TKey key)
		{
			if (frequencyList.TryGetValue(frequency, out var list))
			{
				list.Remove(key);
				if (list.Count == 0)
					frequencyList.Remove(frequency);
			}
		}

		private IEnumerable<KeyValuePair<TKey, TValue>> GetOrderedItems()
		{
			switch (Policy)
			{
				case EvictionPolicy.FIFO:
				case EvictionPolicy.LRU:
					foreach (var key in order)
						yield return new KeyValuePair<TKey, TValue>(key, store[key].Value);
					break;

				case EvictionPolicy.LFU:
					foreach (var freq in frequencyList.OrderBy(pair => pair.Key))
					{
						foreach (var key in freq.Value)
						{
							yield return new KeyValuePair<TKey, TValue>(key, store[key].Value);
						}
					}
					break;
				default:
					throw new InvalidOperationException("Unknown eviction policy.");
			}
		}
	}
}