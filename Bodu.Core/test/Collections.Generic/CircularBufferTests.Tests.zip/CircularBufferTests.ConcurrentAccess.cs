namespace Bodu.Collections.Generic
{
	public partial class CircularBufferTests
	{
		/// <summary>
		/// Verifies that simultaneous access to the buffer from multiple threads does not throw
		/// unexpectedly (not thread-safe).
		/// </summary>
		[TestMethod]
		public void ConcurrentAccess_WhenUnsynchronized_ShouldNotThrowButIsNotThreadSafe()
		{
			var buffer = new CircularBuffer<int>(100);

			var writer = new Thread(() =>
			{
				for (int i = 0; i < 1000; i++)
				{
					buffer.TryEnqueue(i);
				}
			});

			var reader = new Thread(() =>
			{
				for (int i = 0; i < 1000; i++)
				{
					buffer.TryDequeue(out _);
				}
			});

			writer.Start();
			reader.Start();

			writer.Join();
			reader.Join();

			// Since it's not thread-safe, we only verify that it doesn't crash � correctness is not guaranteed.
			Assert.IsTrue(buffer.Count >= 0);
		}
	}
}