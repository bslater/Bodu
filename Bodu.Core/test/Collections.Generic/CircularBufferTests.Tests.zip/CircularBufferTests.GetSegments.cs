namespace Bodu.Collections.Generic
{
	public partial class CircularBufferTests
	{
		/// <summary>
		/// Verifies that <see cref="CircularBuffer{T}.GetSegments" /> returns a single contiguous
		/// segment when data is not wrapped.
		/// </summary>
		[TestMethod]
		public void GetSegments_ShouldReturnSingleSegment_WhenDataIsContiguous()
		{
			var buffer = new CircularBuffer<int>(4);
			buffer.Enqueue(1);
			buffer.Enqueue(2);

			var segments = buffer.GetSegments();
			var combined = segments.FirstSegment.Concat(segments.SecondSegment).ToArray();

			CollectionAssert.AreEqual(new[] { 1, 2 }, combined);
		}

		/// <summary>
		/// Verifies that <see cref="CircularBuffer{T}.GetSegments" /> returns two wrapped segments
		/// when data has wrapped around.
		/// </summary>
		[TestMethod]
		public void GetSegments_ShouldReturnTwoSegments_WhenDataIsWrapped()
		{
			var buffer = new CircularBuffer<int>(3);
			buffer.Enqueue(1);
			buffer.Enqueue(2);
			buffer.Enqueue(3);
			buffer.Dequeue();       // removes 1
			buffer.Enqueue(4);      // wraps around

			var segments = buffer.GetSegments();
			var combined = segments.FirstSegment.Concat(segments.SecondSegment).ToArray();

			CollectionAssert.AreEqual(new[] { 2, 3, 4 }, combined);
		}

		/// <summary>
		/// Verifies that <see cref="CircularBuffer{T}.GetSegments" /> returns empty segments when
		/// the buffer is empty.
		/// </summary>
		[TestMethod]
		public void GetSegments_ShouldReturnEmptySegments_WhenBufferIsEmpty()
		{
			var buffer = new CircularBuffer<string>(2);
			var segments = buffer.GetSegments();

			Assert.AreEqual(0, segments.FirstSegment.Count);
			Assert.AreEqual(0, segments.SecondSegment.Count);
		}
	}
}