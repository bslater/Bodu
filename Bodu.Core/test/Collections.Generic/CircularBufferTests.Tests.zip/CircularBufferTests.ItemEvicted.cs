namespace Bodu.Collections.Generic
{
	public partial class CircularBufferTests
	{
		/// <summary>
		/// Verifies that ItemEvicted is raised with the correct item when an element is overwritten.
		/// </summary>
		[TestMethod]
		public void ItemEvicted_WhenOverwriteOccurs_ShouldContainCorrectItem()
		{
			var evictedItems = new List<string>();
			var buffer = new CircularBuffer<string>(2, allowOverwrite: true);
			buffer.ItemEvicted += item => evictedItems.Add(item);

			buffer.Enqueue("X");
			buffer.Enqueue("Y");
			buffer.Enqueue("Z"); // Should evict "X"

			CollectionAssert.AreEqual(new[] { "X" }, evictedItems);
		}

		/// <summary>
		/// Verifies that ItemEvicted is not raised when overwrite is not allowed.
		/// </summary>
		[TestMethod]
		public void ItemEvicted_WhenOverwriteIsDisabled_ShouldNotFire()
		{
			bool anyEventFired = false;
			var buffer = new CircularBuffer<int>(2, allowOverwrite: false);
			buffer.ItemEvicted += _ => anyEventFired = true;

			buffer.Enqueue(1);
			buffer.Enqueue(2);
			var success = buffer.TryEnqueue(3); // Should not overwrite or fire event

			Assert.IsFalse(success);
			Assert.IsFalse(anyEventFired);
		}

		/// <summary>
		/// Verifies that ItemEvicted is not raised when the buffer has capacity available.
		/// </summary>
		[TestMethod]
		public void ItemEvicted_WhenBufferHasCapacity_ShouldNotFire()
		{
			bool anyEventFired = false;
			var buffer = new CircularBuffer<int>(3, allowOverwrite: true);
			buffer.ItemEvicted += _ => anyEventFired = true;

			buffer.Enqueue(1);
			buffer.Enqueue(2); // Buffer not full

			Assert.IsFalse(anyEventFired);
		}
	}
}