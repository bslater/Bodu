namespace Bodu.Collections.Generic
{
	[TestClass]
	public partial class CircularBufferTests
	{
		private const int DefaultCapacity = 16;
	}
}