﻿namespace Bodu.Buffers
{
	[TestClass]
	public partial class PooledBufferBuilderTests
	{
	}
}