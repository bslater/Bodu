﻿namespace Bodu.Collections.Extensions
{
	[TestClass]
	public abstract partial class IEnumerableExtensionsTests
		: EnumerableTests
	{ }
}