﻿namespace Bodu.Collections.Extensions.SequenceGenerationTests
{
	public class SequenceGeneration
	{
	}
}