﻿namespace Bodu.Collections.Generic.Extensions
{
	[TestClass]
	public partial class IEnumerableExtensionsTests
	{
	}
}