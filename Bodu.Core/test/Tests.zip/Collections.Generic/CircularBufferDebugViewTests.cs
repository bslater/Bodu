﻿namespace Bodu.Collections.Generic
{
	[TestClass]
	public partial class CircularBufferDebugViewTests
	{
	}
}