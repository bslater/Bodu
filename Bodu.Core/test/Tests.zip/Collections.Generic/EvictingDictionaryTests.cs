namespace Bodu.Collections.Generic
{
	[TestClass]
	public partial class EvictingDictionaryTests
	{
		public const int DefaultCapacity = 16;
	}
}