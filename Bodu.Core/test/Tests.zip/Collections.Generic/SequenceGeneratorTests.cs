﻿namespace Bodu.Collections.Generic
{
	[TestClass]
	public partial class SequenceGeneratorTests
		: EnumerableTests
	{
	}
}