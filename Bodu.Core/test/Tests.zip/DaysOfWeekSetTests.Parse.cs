﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bodu
{
	public partial class DaysOfWeekSetTests
	{
		[TestMethod]
		[DynamicData(nameof(DaysOfWeekSetTests.GetValidParseTestCases), typeof(DaysOfWeekSetTests))]
		public void Parse_WheValidInput_ShouldReturnExpected(string input, string _, byte expected)
		{
			var result = DaysOfWeekSet.Parse(input);
			Assert.AreEqual(expected, result);
		}
	}
}