﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bodu
{
	public partial class DaysOfWeekSetTests
	{
		[DataTestMethod]
		[DynamicData(nameof(GetAllDayOfWeekSetPermutationsWithStrings), DynamicDataSourceType.Method)]
		public void ParseExact_WhenSundayFormat_ShouldSetCorrectBit(int expected, string input, string _)
		{
			var result = DaysOfWeekSet.ParseExact(input, "S");
			Assert.AreEqual(expected, (byte)result);
		}

		[DataTestMethod]
		[DynamicData(nameof(GetAllDayOfWeekSetPermutationsWithStrings), DynamicDataSourceType.Method)]
		public void ParseExact_WhenBinaryFormat_ShouldSetCorrectBit(int expected, string _, string input)
		{
			var result = DaysOfWeekSet.ParseExact(input, "B");
			Assert.AreEqual(expected, (byte)result);
		}

		[TestMethod]
		[DynamicData(nameof(DaysOfWeekSetTests.GettInvalidParseWithFormatTestCases), typeof(DaysOfWeekSetTests))]
		public void ParseExact_WhenInvalidInput_ShouldThrowExactly(string input, string format)
		{
			Assert.ThrowsExactly<FormatException>(() =>
			{
				_ = DaysOfWeekSet.ParseExact(input, format);
			});
		}

		[TestMethod]
		[DynamicData(nameof(DaysOfWeekSetTests.GetInvalidFormatParseTestCases), typeof(DaysOfWeekSetTests))]
		public void ParseExact_WheValidInput_ShouldThrowExactly(string input, string format)
		{
			Assert.ThrowsExactly<FormatException>(() =>
			{
				DaysOfWeekSet.ParseExact(input, format);
			});
		}

		[TestMethod]
		[DynamicData(nameof(DaysOfWeekSetTests.GetValidParseWithFormatTestCases), typeof(DaysOfWeekSetTests))]
		public void ParseExact_WheValidInput_ShouldThrowFormatException(string input, string format, byte expected)
		{
			var result = DaysOfWeekSet.ParseExact(input, format);
			Assert.AreEqual(expected, result);
		}

		[TestMethod]
		public void ParseExact_WhenInvalidFormat_ShouldThrowFormatException()
		{
			Assert.ThrowsException<FormatException>(() =>
			{
				DaysOfWeekSet.ParseExact("SMTWTFS", "X");
			});
		}

		[TestMethod]
		public void ParseExact_WhenNullInput_ShouldThrowFormatException()
		{
			Assert.ThrowsException<FormatException>(() =>
			{
				DaysOfWeekSet.ParseExact(null!, "S");
			});
		}

		[TestMethod]
		public void ParseExact_WhenNullFormat_ShouldThrowExactly()
		{
			Assert.ThrowsExactly<ArgumentNullException>(() =>
			{
				DaysOfWeekSet.ParseExact("SMTWTFS", null!);
			});
		}

		[TestMethod]
		public void ParseExact_WhenWrongLengthInput_ShouldThrowExactly()
		{
			Assert.ThrowsException<FormatException>(() =>
			{
				DaysOfWeekSet.ParseExact("SMTWT", "S");
			});
		}
	}
}