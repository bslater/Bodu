﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bodu
{
	public partial class DaysOfWeekSetTests
	{
		[TestMethod]
		public void ToString_WhenCalledWithoutParameters_ShouldUseDefaultFormat()
		{
			var set = new DaysOfWeekSet(DayOfWeek.Sunday, DayOfWeek.Monday);
			string output = set.ToString();
			Assert.AreEqual("SM_____", output);
		}

		[DataTestMethod]
		[DataRow("S", "SM____S")] // Sunday-first
		[DataRow("s", "SM____S")]
		[DataRow("M", "M____SS")] // Monday-first
		[DataRow("m", "M____SS")]
		[DataRow("B", "1100001")] // Binary (Sunday + Monday + Saturday selected)
		[DataRow("b", "1100001")]
		public void ToString_WhenValidFormat_ShouldFormatCorrectly(string format, string expected)
		{
			var set = new DaysOfWeekSet(DayOfWeek.Sunday, DayOfWeek.Monday, DayOfWeek.Saturday);
			string output = set.ToString(format);
			Assert.AreEqual(expected, output);
		}

		[TestMethod]
		public void ToString_WhenInvalidFormat_ShouldThrowArgumentException()
		{
			var set = new DaysOfWeekSet(DayOfWeek.Monday);
			Assert.ThrowsException<ArgumentException>(() => set.ToString("X"));
		}

		[DataTestMethod]
		[DataRow("S", "SM____S")] // Sunday-first
		[DataRow("M", "M____SS")] // Monday-first
		[DataRow("B", "1100001")] // Binary
		public void ToString_WhenFormatAndProviderProvided_ShouldFormatCorrectly(string format, string expected)
		{
			var set = new DaysOfWeekSet(DayOfWeek.Sunday, DayOfWeek.Monday, DayOfWeek.Saturday);
			string output = set.ToString(format, null);
			Assert.AreEqual(expected, output);
		}

		[TestMethod]
		public void ToString_WhenOnlyProviderProvided_ShouldUseDefaultFormat()
		{
			var set = new DaysOfWeekSet(DayOfWeek.Sunday, DayOfWeek.Monday);
			string output = set.ToString(provider: null);
			Assert.AreEqual("SM_____", output);
		}

		private static IEnumerable<object[]> GetAllDayOfWeekSetPermutationsWithStrings()
		{
			char[] symbols = new[] { 'S', 'M', 'T', 'W', 'T', 'F', 'S' }; // Sunday-first

			for (int mask = 0b0000000; mask <= 0b1111111; mask++) // From 0 to 127
			{
				var symbolBuilder = new char[7];
				var binaryBuilder = new char[7];

				for (int i = 0; i < 7; i++)
				{
					bool bitSet = ((mask >> (6 - i)) & 1) == 1;

					symbolBuilder[i] = bitSet ? symbols[i] : '_';
					binaryBuilder[i] = bitSet ? '1' : '0';
				}

				string symbol = new string(symbolBuilder);
				string binary = new string(binaryBuilder);

				yield return new object[] { (byte)mask, symbol, binary };
			}
		}

		[DataTestMethod]
		[DynamicData(nameof(GetAllDayOfWeekSetPermutationsWithStrings), DynamicDataSourceType.Method)]
		public void ToString_WhenCalled_ShouldReturnUpperString(byte value, string expected, string _)
		{
			var set = DaysOfWeekSet.FromByte(value);
			Assert.AreEqual(expected, set.ToString());
		}

		[DataTestMethod]
		[DynamicData(nameof(GetAllDayOfWeekSetPermutationsWithStrings), DynamicDataSourceType.Method)]
		public void ToString_WhenBinaryFormat_ShouldReturnUpperString(byte value, string _, string expected)
		{
			var set = DaysOfWeekSet.FromByte(value);
			Assert.AreEqual(expected, set.ToString("b"));
		}
	}
}