﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bodu
{
	public partial class DaysOfWeekSetTests
	{
		[DataTestMethod]
		[DataRow("SMTWTFS", true, (byte)0b1111111)]
		[DataRow("_______", true, (byte)0b0000000)]
		[DataRow("1010101", false, (byte)0b1010101)]
		[DataRow("", false, (byte)0)]
		[DataRow("Invalid", false, (byte)0)]
		[DataRow(null, false, (byte)0)]
		public void TryParse_WhenGivenInput_ShouldReturnExpectedResultAndParsedValue(string input, bool expectedSuccess, byte expected)
		{
			bool success = DaysOfWeekSet.TryParse(input, out var result);
			Assert.AreEqual(expectedSuccess, success);
			if (success)
			{
				Assert.AreEqual(expected, (byte)result);
			}
		}
	}
}