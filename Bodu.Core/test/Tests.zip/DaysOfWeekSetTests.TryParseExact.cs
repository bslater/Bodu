﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bodu
{
	public partial class DaysOfWeekSetTests
	{
		[DataTestMethod]
		[DataRow("SMTWTFS", "S", true, (byte)0b1111111)]
		[DataRow("MTWTFSS", "M", true, (byte)0b1111111)]
		[DataRow("1010101", "B", true, (byte)0b1010101)]
		[DataRow("SMTWT", "S", false, (byte)0)] // too short
		[DataRow("XXXXXXX", "S", false, (byte)0)] // wrong letters
		[DataRow("101X101", "B", false, (byte)0)] // invalid binary
		[DataRow(null, "S", false, (byte)0)]
		[DataRow("SMTWTFS", null, false, (byte)0)]
		[DataRow("SMTWTFS", "X", false, (byte)0)]
		public void TryParseExact_WhenGivenInputAndFormat_ShouldReturnExpectedResultAndParsedValue(string input, string format, bool expectedSuccess, byte expected)
		{
			bool success = DaysOfWeekSet.TryParseExact(input, format, out var result);
			Assert.AreEqual(expectedSuccess, success);
			if (success)
			{
				Assert.AreEqual(expected, (byte)result);
			}
		}
	}
}