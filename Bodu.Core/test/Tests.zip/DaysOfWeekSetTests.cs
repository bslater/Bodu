﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bodu
{
	[TestClass]
	public partial class DaysOfWeekSetTests
	{
		public static IEnumerable<object[]> GetValidParseWithFormatTestCases() => GetValidParseTestCases().Where(o => o[1] != null);

		/// <summary>
		/// Provides a comprehensive set of valid test cases for parsing DaysOfWeekSet, including case variations.
		/// </summary>
		public static IEnumerable<object[]> GetValidParseTestCases()
		{
			// Default auto-detect cases (null format)
			yield return new object[] { "SMTWTFS", null, (byte)0b1111111 };  // Sunday-first
			yield return new object[] { "smtwtfs", null, (byte)0b1111111 };  // Sunday-first lowercase
			yield return new object[] { "MTWTFSS", null, (byte)0b1111111 };  // Monday-first
			yield return new object[] { "mtwtfss", null, (byte)0b1111111 };  // Monday-first lowercase
			yield return new object[] { "1010101", null, (byte)0b1010101 };  // Binary auto-detect

			// Explicit binary format
			yield return new object[] { "1010101", "B", (byte)0b1010101 };
			yield return new object[] { "1010101", "b", (byte)0b1010101 };   // lower-case 'b'
			yield return new object[] { "1110000", "B", (byte)0b1110000 };
			yield return new object[] { "0001111", "b", (byte)0b0001111 };

			// Sunday-first with explicit unselected characters
			yield return new object[] { "S_TWTFS", "SU", (byte)0b1011111 };
			yield return new object[] { "S_TWTFS", "su", (byte)0b1011111 };
			yield return new object[] { "S-TWTFS", "SD", (byte)0b1011111 };
			yield return new object[] { "S-TWTFS", "sd", (byte)0b1011111 };
			yield return new object[] { "S*TWTFS", "SA", (byte)0b1011111 };
			yield return new object[] { "S*TWTFS", "sa", (byte)0b1011111 };
			yield return new object[] { "S TWTFS", "SB", (byte)0b1011111 };
			yield return new object[] { "S TWTFS", "sb", (byte)0b1011111 };

			// Monday-first with explicit unselected characters
			yield return new object[] { "M_WTF_S", "MU", (byte)0b1101110 };
			yield return new object[] { "M_WTF_S", "mu", (byte)0b1101110 };
			yield return new object[] { "M-WTF-S", "MD", (byte)0b1101110 };
			yield return new object[] { "M-WTF-S", "md", (byte)0b1101110 };
			yield return new object[] { "M*WTF*S", "MA", (byte)0b1101110 };
			yield return new object[] { "M*WTF*S", "ma", (byte)0b1101110 };
			yield return new object[] { "M WTF S", "MB", (byte)0b1101110 };
			yield return new object[] { "M WTF S", "mb", (byte)0b1101110 };

			// Mixed selection examples
			yield return new object[] { "S_T_T_S", "SU", (byte)0b1010101 };
			yield return new object[] { "s_t_t_s", "su", (byte)0b1010101 };
			yield return new object[] { "M-W-F--", "MD", (byte)0b0101010 };
			yield return new object[] { "m-w-f--", "md", (byte)0b0101010 };
			yield return new object[] { "1010101", "B", (byte)0b1010101 };
			yield return new object[] { "1010101", "b", (byte)0b1010101 };
			yield return new object[] { "1111111", "B", (byte)0b1111111 };
			yield return new object[] { "0000000", "b", (byte)0b0000000 };

			// Explicit format overrides
			yield return new object[] { "SMTWTFS", "S", (byte)0b1111111 };
			yield return new object[] { "smtwtfs", "s", (byte)0b1111111 };
			yield return new object[] { "MTWTFSS", "M", (byte)0b1111111 };
			yield return new object[] { "mtwtfss", "m", (byte)0b1111111 };

			// empty
			yield return new object[] { "       ", null, (byte)0b0000000 };
			yield return new object[] { "-------", null, (byte)0b0000000 };
			yield return new object[] { "*******", null, (byte)0b0000000 };
			yield return new object[] { "_______", null, (byte)0b0000000 };
			yield return new object[] { "0000000", "b", (byte)0b0000000 };
			yield return new object[] { "       ", "sB", (byte)0b0000000 };
			yield return new object[] { "-------", "sD", (byte)0b0000000 };
			yield return new object[] { "*******", "sa", (byte)0b0000000 };
			yield return new object[] { "_______", "mu", (byte)0b0000000 };
		}

		public static IEnumerable<object[]> GettInvalidParseWithFormatTestCases() => GetInvalidParseTestCases().Where(o => o[1] != null);

		/// <summary>
		/// Provides a comprehensive set of invalid test cases for parsing DaysOfWeekSet, including case variations.
		/// </summary>
		public static IEnumerable<object[]> GetInvalidParseTestCases()
		{
			// Wrong length
			yield return new object[] { "", null };
			yield return new object[] { "SMTWTF", null };
			yield return new object[] { "SMTWTFSS", null };

			// Invalid characters
			yield return new object[] { "SXTWTFS", null }; // 'X' invalid
			yield return new object[] { "mxtwtfs", null }; // lower 'x' invalid
			yield return new object[] { "M1WTFSS", null }; // '1' unexpected
			yield return new object[] { "m1wtfss", null }; // lower '1'

			// Invalid binary input
			yield return new object[] { "1200101", "B" };
			yield return new object[] { "1200101", "b" };
			yield return new object[] { "ABCDEF1", "B" };
			yield return new object[] { "abcdef1", "b" };
			yield return new object[] { "11X1111", "B" };
			yield return new object[] { "11x1111", "b" };

			// Bad format specifiers
			yield return new object[] { "SMTWTFS", "X" };
			yield return new object[] { "SMTWTFS", "x" };
			yield return new object[] { "SMTWTFS", "SZ" }; // invalid unselected character
			yield return new object[] { "SMTWTFS", "sz" };

			// Symbol mismatch cases
			yield return new object[] { "S_T-TFS", "SU" }; // '-' unexpected for '_'
			yield return new object[] { "s_t-tfs", "su" };
			yield return new object[] { "M*TWTFS", "MD" }; // '*' unexpected for '-'
			yield return new object[] { "m*twTfs", "md" };

			// Wrong parsing mode
			yield return new object[] { "1010101", "S" }; // binary-looking but forced symbol parsing
			yield return new object[] { "1010101", "s" };
			yield return new object[] { "SMTWTFS", "B" }; // symbol-looking but forced binary parsing
			yield return new object[] { "smtwtfs", "b" };

			// Wrong parsing mode
			yield return new object[] { "SMTWTFS", "Invalid" };
			yield return new object[] { "SMTWTFS", "" };
			yield return new object[] { "SMTWTFS", "123" };
			yield return new object[] { "SMTWTFS", "SUU" };
		}

		public static IEnumerable<object[]> GetInvalidFormatParseTestCases()
		{
			// Bad format specifiers
			yield return new object[] { "SMTWTFS", "X" };
			yield return new object[] { "SMTWTFS", "x" };
			yield return new object[] { "SMTWTFS", "SZ" }; // invalid unselected character
			yield return new object[] { "SMTWTFS", "sz" };
			yield return new object[] { "SMTWTFS", "Invalid" };
			yield return new object[] { "SMTWTFS", "" };
			yield return new object[] { "SMTWTFS", "123" };
			yield return new object[] { "SMTWTFS", "SUU" };

			// Wrong parsing mode
			yield return new object[] { "1010101", "S" }; // binary-looking but forced symbol parsing
			yield return new object[] { "1010101", "s" };
			yield return new object[] { "SMTWTFS", "B" }; // symbol-looking but forced binary parsing
			yield return new object[] { "smtwtfs", "b" };
		}
	}
}