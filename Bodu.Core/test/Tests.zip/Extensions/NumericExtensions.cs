﻿namespace Bodu.Extensions.NumericExtensionsTests
{
	[TestClass]
	public class NumericExtensions
	{ }
}