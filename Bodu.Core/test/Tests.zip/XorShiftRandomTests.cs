﻿namespace Bodu
{
	[TestClass]
	public partial class XorShiftRandomTests
	{
	}
}